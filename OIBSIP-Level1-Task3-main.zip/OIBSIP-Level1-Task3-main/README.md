# OIBSIP-Level1-Task3
TEMPERATURE CONVERTER WEBSITE. The user will input a temperature in either Fahrenheit or Celsius and press a "convert" button. The converted temperature will then be displayed with the correct unit.
